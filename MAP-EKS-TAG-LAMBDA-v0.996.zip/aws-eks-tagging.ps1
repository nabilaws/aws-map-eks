#Requires -Modules @{ModuleName='AWS.Tools.Common';ModuleVersion='4.0.6.0'}
#Requires -Module AWS.Tools.EC2, AWS.Tools.AutoScaling, AWS.Tools.EKS
#1: Tag your EKS Node during deployment
#2: CWE trap with details to moify ASG
#3: Customer need to refresh node group instances or wait for recycle
#Print Event
Write-Host 'Log group name:' $LambdaContext.LogGroupName

$jsonTags = $vJson2.detail.requestParameters.tags
$eksASG = $vJson2.detail.requestParameters.autoScalingGroupName
Write-Information -MessageData "LambdaInput.detail.requestParameters.tags.value"
Write-Host $LambdaInput.detail.requestParameters.tags.value
Write-Host $LambdaInput.source
Write-Host $LambdaInput.detail.eventName
Write-Information -MessageData "Grace period"
Write-Host $LambdaInput.detail.requestParameters.healthCheckGracePeriod
try {
   $ClusterName = ($LambdaInput.detail.requestParameters.tags | Where-Object key -eq "eks:cluster-name").Value 
   $NodeName = ($LambdaInput.detail.requestParameters.tags | Where-Object key -eq "eks:nodegroup-name").Value
}
catch {
   Write-Host $($_.exception.message)
}
if($ClusterName -or $NodeName -eq $null){
   Write-Error "Dong! Json not deserialized"
}
Write-Information -Message "Node and Cluster names from tags"
Write-Host $NodeName $ClusterName   
#Retrieve Cluster Tagging 
$MAPTagValue = (Get-EKSNodegroup -ClusterName $ClusterName -NodegroupName $NodeName).Tags.Values
#Prepare AS Tags
$EKSTags = (New-Object Amazon.AutoScaling.Model.Tag)
$EKSTags.ResourceType = "auto-scaling-group"
$EKSTags.ResourceId = $LambdaInput.detail.requestParameters.autoScalingGroupName
$EKSTags.Key = "map-migrated"
$EKSTags.Value = $MAPTagValue
$EKSTags.PropagateAtLaunch = $true
#Aplpy Tags to ASG for future launch 
Set-ASTag -Tag $EKSTags  