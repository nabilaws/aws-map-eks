
#Requires -Modules @{ModuleName='AWS.Tools.Common';ModuleVersion='4.0.6.0'}

#Requires -Module AWS.Tools.EC2, AWS.Tools.AutoScaling, AWS.Tools.SimpleSystemsManagement
#1:  Update the ASG and or Launch Template create by EKS (requires )
#2:  Provide a Cloudformation logic for Cluster creation (with instant modification of the ASG and Launch template to include map tags)

#Print Event
Write-Host (ConvertTo-Json -InputObject $LambdaInput -Compress -Depth 5)

$EKSTags = (New-Object Amazon.AutoScaling.Model.Tag)
